function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


$(document).ready(function(){
  $('.login-info-box').fadeOut();
  $('.login-show').addClass('show-log-panel');
});


$('.login-reg-panel input[type="radio"]').on('change', function() {
  if($('#log-login-show').is(':checked')) {
      $('.register-info-box').fadeOut(); 
      $('.login-info-box').fadeIn();
      
      $('.white-panel').addClass('right-log');
      $('.register-show').addClass('show-log-panel');
      $('.login-show').removeClass('show-log-panel');
  }
  else if($('#log-reg-show').is(':checked')) {
      $('.register-info-box').fadeIn();
      $('.login-info-box').fadeOut();
      
      $('.white-panel').removeClass('right-log');
      
      $('.login-show').addClass('show-log-panel');
      $('.register-show').removeClass('show-log-panel');
  }
});
$('#register').on('click', function(){
     $('.register-show').addClass('show-log-panel');
      $('.login-show').removeClass('show-log-panel');
})
$('#login').on('click', function(){
  $('.login-show').addClass('show-log-panel');
      $('.register-show').removeClass('show-log-panel');
})

var uniqueEmail = false;
var passMatched = false

  $('#email').on('keyup', function(){
      var parameters = { search: $(this).val() };
        $.get( '/emailsearching',parameters, function(data) {
          if(data.length > 0){
            $("#Emailpoper").popover('show');
            uniqueEmail = false;
          }else{
            $("#Emailpoper").popover('hide');
            uniqueEmail = true;
          }
      });
  });

  $('#submitReg').on('click', function(){
    var pass = $('#pass').val()
    var cpass = $('#cpass').val()
    if(pass != cpass){
      $("#passPoper").popover('show') 
      passMatched = false;
      }else{
        $("#passPoper").popover('hide');
        passMatched = true;
      }
      if(uniqueEmail == true && passMatched == true){
        $("#regform").submit(function(e){
          e.currentTarget.submit();
        }) 
      }else{
        $("#regform").submit(function(e){
          e.preventDefault()
        })
      }
  })
  $('#add_channel').on('click', function(){
    var channel_id = $('#room-id').val()
    var desc = $('#description').val()
    var parameters = { channelId:channel_id, description:desc };
    $.get( '/addChannel', parameters, function(data) {
      if(data.length > 0){
        alert("This Channel is already Created")
      }else{
        $('#description').val("")
        alert("Channel successfuly Created")
      }
    })

  })
  $('#goLive, #ChannelBtn, #watch_list').on('click', function(){
    channels()
  })
  function channels(){
    $.get( '/SelectChannel', function(data) {
      if(data.length > 0){
        $('.channel_list option[value]').remove();
        $('.channel_list').append('<option value="" selected>Select a channel</option>')
        $.each(data, function(index){
          $('.channel_list').append(
            '<option value="'+data[index].channel_id+'">'+data[index].channel_id+' ('+data[index].description+')'+'</option>'
            )
        })
      }else{
        $('.channel_list').append('<option>No Channel Found</option>')
      }
    })
  }
  $('#remove_channel').on('click', function(){
    var channel = $('#channel_list-remove').val()
    var parameters = { channelId:channel};
    $.get( '/removeChannel', parameters, function(data) {
      if(data.length > 0){
        alert('Channel Removed')
      }
    })
  })
  
  $("#select_broadcaster").click(function(){
      var favorite = [];
      $.each($("input[name='select']:checked"), function(){
          favorite.push($(this).val());
      });
      var parameters = { broadcasters:favorite};
      $.get( '/broadcastersList', parameters, function(data) {
          if(data.length>0){
            alert("updated")
          }else{
            alert("not update")
          }
      })
  });
  $('#broadcasters_list').on('click', function(){
    $('#broadcasters_list_remove option[value]').remove();
    $('#broadcasters_list_remove').append('<option value="" selected>Select a Broadcaster</option>')
    $.get( '/broadcastersList_remove', function(data) {
        if(data.length > 0){
          $.each(data, function(index){
            $('#broadcasters_list_remove').append(
              '<option value="'+data[index].id+'">'+data[index].username+'</option>'
              )
          })
        }
    })
  })
  $('#remove_broadcaster').on('click', function(){
    var broadcaster = $('#broadcasters_list_remove').val()
    var parameters = { broadcasterId:broadcaster};
    $.get( '/remove_broadcaster', parameters, function(data) {
      if(data.length > 0){
        alert("Broadcaster Removed")
      }
    })
  })
  $("#d-block").click(function(){
    $("#videos-container").toggleClass("d-block");
  });