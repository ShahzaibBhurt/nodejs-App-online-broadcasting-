// ......................................................
// ..................RTCMultiConnection Code.............
// ......................................................

var connection = new RTCMultiConnection();

// by default, socket.io server is assumed to be deployed on your own URL
connection.socketURL = '/';

// comment-out below line if you do not have your own socket.io server
// connection.socketURL = 'https://rtcmulticonnection.herokuapp.com:443/';

connection.socketMessageEvent = 'video-conference-demo';

var socketio = io();  
var mediaStream;
// ......................................................
// .......................UI Code........................
// ......................................................
if(document.getElementById('GO_LIVE') != undefined){
    document.getElementById('GO_LIVE').onclick = function() {
        var channel_list = document.getElementById('channel_list').value
        if(channel_list.length > 0){
            //disableInputButtons();
            connection.open(channel_list, function(isRoomOpened, roomid, error) {
                if(isRoomOpened === true) {
                //showRoomURL(connection.sessionid);
                    connection.session = {
                        audio: true,
                        video: true,
                        oneway: false
                    };   
                }else {
                    connection.join(channel_list, function(isJoinedRoom, roomid, error) {
                        if (error) {
                                //disableInputButtons(true);
                                if(error === 'Room not available') {
                                alert('This room does not exist. Please either create it or wait for moderator to enter in the room.');
                                return;
                                }
                                alert(error);
                            }
                            connection.session = {
                                audio: true,
                                video: true,
                                oneway: false
                            };
                        });
                //disableInputButtons(true);
                    }
                    
            });
        }else{
            alert('Plz Select a Channel')
        }
        setTimeout(function() {
            $('#uploadBox_model').modal('show');
            Recordings();
        }, 3300000);
    };
}
/*
document.getElementById('join-room').onclick = function() {
    disableInputButtons();
    connection.join(document.getElementById('room-id').value, function(isJoinedRoom, roomid, error) {
      if (error) {
            disableInputButtons(true);
            if(error === 'Room not available') {
              alert('This room does not exist. Please either create it or wait for moderator to enter in the room.');
              return;
            }
            alert(error);
        }
        connection.session = {
            audio: true,
            video: true,
            oneway: false
        };
    });
};    
    */
if(document.getElementById('watch') != undefined){
    document.getElementById('watch').onclick = function() {
        //disableInputButtons();
        connection.session = {
        audio: true,
        video: true,
        oneway: true
    };
        connection.sdpConstraints.mandatory = {
            OfferToReceiveAudio: true,
            OfferToReceiveVideo: true
        };
        connection.join(document.getElementById('channel_list').value);
        
        
    };
}

connection.sdpConstraints.mandatory = {
    OfferToReceiveAudio: false,
    OfferToReceiveVideo: false
};

// STAR_FIX_VIDEO_AUTO_PAUSE_ISSUES
// via: https://github.com/muaz-khan/RTCMultiConnection/issues/778#issuecomment-524853468
var bitrates = 512;
var resolutions = 'Ultra-HD';
var videoConstraints = {};

if (resolutions == 'HD') {
    videoConstraints = {
        width: {
            ideal: 1280
        },
        height: {
            ideal: 720
        },
        frameRate: 30
    };
}

if (resolutions == 'Ultra-HD') {
    videoConstraints = {
        width: {
            ideal: 1920
        },
        height: {
            ideal: 1080
        },
        frameRate: 30
    };
}

connection.mediaConstraints = {
    video: videoConstraints,
    audio: true
};

var CodecsHandler = connection.CodecsHandler;

connection.processSdp = function(sdp) {
    var codecs = 'vp8';
    
    if (codecs.length) {
        sdp = CodecsHandler.preferCodec(sdp, codecs.toLowerCase());
    }

    if (resolutions == 'HD') {
        sdp = CodecsHandler.setApplicationSpecificBandwidth(sdp, {
            audio: 128,
            video: bitrates,
            screen: bitrates
        });

        sdp = CodecsHandler.setVideoBitrates(sdp, {
            min: bitrates * 8 * 1024,
            max: bitrates * 8 * 1024,
        });
    }

    if (resolutions == 'Ultra-HD') {
        sdp = CodecsHandler.setApplicationSpecificBandwidth(sdp, {
            audio: 128,
            video: bitrates,
            screen: bitrates
        });

        sdp = CodecsHandler.setVideoBitrates(sdp, {
            min: bitrates * 8 * 1024,
            max: bitrates * 8 * 1024,
        });
    }

    return sdp;
};
// END_FIX_VIDEO_AUTO_PAUSE_ISSUES

// https://www.rtcmulticonnection.org/docs/iceServers/
// use your own TURN-server here!
connection.iceServers = [{
    'urls': [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302',
        'stun:stun.l.google.com:19302?transport=udp',
    ]
}];

connection.videosContainer = document.getElementById('videos-container');
connection.onstream = function(event) {
    var existing = document.getElementById(event.streamid);
    if(existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }

    event.mediaElement.removeAttribute('src');
    event.mediaElement.removeAttribute('srcObject');
    event.mediaElement.muted = true;
    event.mediaElement.volume = 0;

    var video = document.createElement('video');

    try {
        video.setAttributeNode(document.createAttribute('autoplay'));
        video.setAttributeNode(document.createAttribute('playsinline'));
    } catch (e) {
        video.setAttribute('autoplay', true);
        video.setAttribute('playsinline', true);
    }

    if(event.type === 'local') {
      video.volume = 0;
      try {
          video.setAttributeNode(document.createAttribute('muted'));
      } catch (e) {
          video.setAttribute('muted', true);
      }
    }
    video.srcObject = event.stream;

    

    var width = parseInt(connection.videosContainer.clientWidth / 3) - 20;
    var mediaElement = getHTMLMediaElement(video, {
        //title: event.userid,
        buttons: ['mute-audio'],
        width: width,
        showOnMouseEnter: false
    });

    connection.videosContainer.appendChild(mediaElement);

    setTimeout(function() {
        mediaElement.media.play();
    }, 5000);

    mediaElement.id = event.streamid;

    // to keep room-id in cache
    localStorage.setItem(connection.socketMessageEvent, connection.sessionid);

    //chkRecordConference.parentNode.style.display = 'none';

   // if(chkRecordConference.checked === true) {
      btnStopRecording.style.visibility = 'visible';
     // recordingStatus.style.display = 'inline-block';

      var recorder = connection.recorder;
      if(!recorder) {
        recorder = RecordRTC([event.stream], {
          type: 'video'
        });
        recorder.startRecording();
        connection.recorder = recorder;
      }
      else {
        recorder.getInternalRecorder().addStreams([event.stream]);
      }

      if(!connection.recorder.streams) {
        connection.recorder.streams = [];
      }

      connection.recorder.streams.push(event.stream);
     // recordingStatus.innerHTML = 'Recording ' + connection.recorder.streams.length + ' streams';
  // }

    if(event.type === 'local') {
      connection.socket.on('disconnect', function() {
        if(!connection.getAllParticipants().length) {
          location.reload();
        }
      });
    }
};

//var recordingStatus = document.getElementById('recording-status');
//var chkRecordConference = document.getElementById('record-entire-conference');
if(document.getElementById('btn-stop-recording') != undefined){
    var btnStopRecording = document.getElementById('btn-stop-recording');
    btnStopRecording.onclick = function() {
        Recordings();
    };
}

function Recordings(){
    var recorder = connection.recorder;
  if(!recorder) return alert('No recorder found.');
  recorder.stopRecording(function() {
    var blob = recorder.getBlob();
    var fileName = generateRandomString() + '.mp4';
                       
      var SelectedFile = new File([blob], fileName, {
                    type: 'video/mp4'
                });
//socketio.emit('message', file);
    //invokeSaveAsDialog(file);
      //var SelectedFile = file;
      
      if(SelectedFile){
          StartUpload();
      }
			//var socket = socketio.connect('https://localhost:3000');
			var FReader;
      //var Name = fileName;
			function StartUpload(){
					FReader = new FileReader();
					var Content = "<span id='NameArea'>Uploading " + SelectedFile.name + "</span>";
					Content += '<div id="ProgressContainer"><div id="ProgressBar"></div></div><span id="percent">50%</span>';
					Content += "<span id='Uploaded'> - <span id='MB'>0</span>/" + Math.round(SelectedFile.size / 1048576) + "MB</span>";
					document.getElementById('UploadArea').innerHTML = Content;
					FReader.onload = function(evnt){
						socketio.emit('Upload', { 'Name' : fileName, Data : evnt.target.result });
					}
					socketio.emit('Start', { 'Name' : fileName, 'Size' : SelectedFile.size });
				
			}
			
			socketio.on('MoreData', function (data){
				UpdateBar(data['Percent']);
				var Place = data['Place'] * 524288; //The Next Blocks Starting Position
				var NewFile; //The Variable that will hold the new Block of Data
				if(SelectedFile.webkitSlice) 
					NewFile = SelectedFile.webkitSlice(Place, Place + Math.min(524288, (SelectedFile.size-Place)));
				else
					NewFile = SelectedFile.slice(Place, Place + Math.min(524288, (SelectedFile.size-Place)));
				FReader.readAsBinaryString(NewFile);
			});
			function UpdateBar(percent){
				document.getElementById('ProgressBar').style.width = percent + '%';
				document.getElementById('percent').innerHTML = (Math.round(percent*100)/100) + '%';
				var MBDone = Math.round(((percent/100.0) * SelectedFile.size) / 1048576);
				document.getElementById('MB').innerHTML = MBDone;
			}
			
			var Path = "https://localhost/";
			
			socketio.on('Done', function (data){
				var Content = "Video Successfully Uploaded !!"
				
				document.getElementById('UploadBox').style.width = '270px';
				document.getElementById('UploadBox').style.height = '270px';
                document.getElementById('UploadBox').style.textAlign = 'center';
                Refresh();
			});
			function Refresh(){
				location.reload(true);
			}
      
      
      
      
      
      

    connection.recorder = null;
    btnStopRecording.style.visibility = 'visible';
   // recordingStatus.style.display = 'none';
   // chkRecordConference.parentNode.style.display = 'inline-block';
  });
}
function generateRandomString() {
                if (window.crypto) {
                    var a = window.crypto.getRandomValues(new Uint32Array(3)),
                        token = '';
                    for (var i = 0, l = a.length; i < l; i++) token += a[i].toString(36);
                    return token;
                } else {
                    return (Math.random() * new Date().getTime()).toString(36).replace( /\./g , '');
                }
            }
connection.onstreamended = function(event) {
    var mediaElement = document.getElementById(event.streamid);
    if (mediaElement) {
        mediaElement.parentNode.removeChild(mediaElement);
    }
};

connection.onMediaError = function(e) {
    if (e.message === 'Concurrent mic process limit.') {
        if (DetectRTC.audioInputDevices.length <= 1) {
            alert('Please select external microphone. Check github issue number 483.');
            return;
        }

        var secondaryMic = DetectRTC.audioInputDevices[1].deviceId;
        connection.mediaConstraints.audio = {
            deviceId: secondaryMic
        };

        connection.join(connection.sessionid);
    }
};

// ..................................
// ALL below scripts are redundant!!!
// ..................................

function disableInputButtons(enable) {
    document.getElementById('room-id').onkeyup();

    document.getElementById('GO_LIVE').disabled = !enable;
    document.getElementById('join-room').disabled = !enable;
    document.getElementById('channel_list').disabled = !enable;
}



// ......................................................
// ......................Handling Room-ID................
// ......................................................
/*
function showRoomURL(roomid) {
    var roomHashURL = '#' + roomid;
    var roomQueryStringURL = '?roomid=' + roomid;

    var html = '<h2>Unique URL for your room:</h2><br>';

    html += 'Hash URL: <a href="' + roomHashURL + '" target="_blank">' + roomHashURL + '</a>';
    html += '<br>';
    html += 'QueryString URL: <a href="' + roomQueryStringURL + '" target="_blank">' + roomQueryStringURL + '</a>';

    var roomURLsDiv = document.getElementById('room-urls');
    roomURLsDiv.innerHTML = html;

    roomURLsDiv.style.display = 'block';
}*/

(function() {
    var params = {},
        r = /([^&=]+)=?([^&]*)/g;

    function d(s) {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    }
    var match, search = window.location.search;
    while (match = r.exec(search.substring(1)))
        params[d(match[1])] = d(match[2]);
    window.params = params;
})();

var roomid = '';
$('#ChannelBtn').on('click', function(){
    if (localStorage.getItem(connection.socketMessageEvent)) {
        roomid = localStorage.getItem(connection.socketMessageEvent);
    } else {
        roomid = connection.token();
    }
    
    var txtRoomId = document.getElementById('room-id');
    txtRoomId.value = roomid;
    txtRoomId.onkeyup = txtRoomId.oninput = txtRoomId.onpaste = function() {
        localStorage.setItem(connection.socketMessageEvent, document.getElementById('room-id').value);
    };
})


var hashString = location.hash.replace('#', '');
if (hashString.length && hashString.indexOf('comment-') == 0) {
    hashString = '';
}

var roomid = params.roomid;
if (!roomid && hashString.length) {
    roomid = hashString;
}

if (roomid && roomid.length) {
    document.getElementById('channel_list').value = roomid;
    localStorage.setItem(connection.socketMessageEvent, roomid);

    // auto-join-room
    (function reCheckRoomPresence() {
        connection.checkPresence(roomid, function(isRoomExist) {
            if (isRoomExist) {
                connection.join(roomid);
                return;
            }

            setTimeout(reCheckRoomPresence, 5000);
        });
    })();

    disableInputButtons();
}

// detect 2G
if(navigator.connection &&
   navigator.connection.type === 'cellular' &&
   navigator.connection.downlinkMax <= 0.115) {
  alert('2G is not supported. Please use a better internet service.');
}