module.exports = function(app, passport) {
 app.get('/', isLoggedIn, function(req, res){
  res.render('index.ejs');
 });

 app.get('/login', isLogin, function(req, res){
  res.render('login.ejs', {message:req.flash('loginMessage')});
 });

 app.post('/login', passport.authenticate('local-login', {
  successRedirect: '/index',
  failureRedirect: '/login',
  failureFlash: true
 }),
  function(req, res){
   if(req.body.remember){
    req.session.cookie.maxAge = 1000 * 60 * 3;
   }else{
    req.session.cookie.expires = false;
   }
   res.redirect('/index');
  });
  app.post('/guest-login', passport.authenticate('local-guest-login', {
    successRedirect: '/index',
    failureRedirect: '/login',
    failureFlash: true
   }),
    function(req, res){
     if(req.body.remember){
      req.session.cookie.maxAge = 1000 * 60 * 3;
     }else{
      req.session.cookie.expires = false;
     }
     res.redirect('/index');
    });

 /*app.get('/signup', isLogin, function(req, res){
  res.render('signup.ejs', {message: req.flash('signupMessage')});
 });*/
 app.post('/plans', function(req, res){
    res.render('plans.ejs', {
        first_name: req.body.firstname,
        last_name: req.body.lastname,
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
    });
   });

 app.post('/register', passport.authenticate('local-signup', {
  successRedirect: '/index',
  failureRedirect: '/login',
  failureFlash: true
 }));
 
var pass = require('../config/passport')
 app.get('/index', isLoggedIn, function(req, res){
  res.render('index.ejs', {
   user:req.user,
   getusers: pass.getUsers
  });
 });

 app.get('/logout', function(req,res){
  req.logout();
  res.redirect('/login');
 })
};

function isLoggedIn(req, res, next){
 if(req.isAuthenticated())
  return next();

 res.redirect('/login');
}
function isLogin(req, res, next){
 if(req.isAuthenticated()){
     res.redirect('/index');
 }else{
     return next();
 }
}