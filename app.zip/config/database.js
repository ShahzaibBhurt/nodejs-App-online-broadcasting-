module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': ''
    },
    'database': 'myalleyway',
    'user_table': 'users'
}