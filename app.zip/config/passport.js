var LocalStrategy = require("passport-local").Strategy;

var mysql = require('mysql');
var bcrypt = require('bcrypt-nodejs');
var dbconfig = require('./database');
var connection = mysql.createConnection(dbconfig.connection);

connection.query('USE ' + dbconfig.database);

module.exports = function (app, passport, stripe) {
    app.get('/emailsearching', function(req, res){
        connection.query("SELECT * FROM users WHERE email = ? ", [req.query.search],
            function(error, results, fields) {
                if(results.length > 0){
                    res.send("exist");
                    console.log("This Email is already exist");
                }else{
                    res.send('');
                }
            });
      });
      app.get('/addChannel', function(req, res){
        connection.query("SELECT * FROM broadcast WHERE channel_id = ?", [req.query.channelId],
            function(error, results, fields) {
                if(results.length > 0){
                    res.send("exist");
                }else{
                    connection.query("INSERT INTO broadcast(channel_id, description) VALUES (?,?)", [req.query.channelId, req.query.description],
                        function(error, results, fields) {
                            res.send('');
                        })
                }
            });
      });
      app.get('/removeChannel', function(req, res){
        connection.query("DELETE FROM broadcast WHERE channel_id = ?", [req.query.channelId],
            function(error, results, fields) {
                if(results.length <= 0){
                    res.send("removed");
                }
            });
      });
      app.get('/broadcastersList', function(req, res){
        for(var i=0;i<req.query.broadcasters.length;i++){
            connection.query("UPDATE users SET role='broadcaster' WHERE id=?", [req.query.broadcasters[i]],
            function(error, results, fields) {
                if(results.length > 0){
                    res.send("Updated");
                }
            });
        }
      });
      app.get('/broadcastersList_remove', function(req, res){
        connection.query("select * from users where role='broadcaster'",
            function(error, results, fields) {
                if(results.length > 0){
                    res.send(results);
                }
            });
      });
      app.get('/remove_broadcaster', function(req, res){
        connection.query("update users set role='user' where id=?", [req.query.broadcasterId],
            function(error, results, fields) {
                if(results.length <= 0){
                    res.send("updated");
                }
            });
      });
      app.get('/SelectChannel', function(req, res){
        connection.query("SELECT * FROM broadcast order by id desc",
            function(error, results, fields) {
                if(results.length > 0){
                    res.send(results);
                }else{
                    res.send('')
                }
            });
      });
      function getInfo(id, callback){
        connection.query("select * from users where id not in(?)", id,
        function(err, results, fields) {
            if(results.length > 0){
               return callback(results)
            }
        })
     }
    passport.serializeUser(function (user, done) {
        if(user.id == undefined){
            done (null, user);
        }else{
            done(null, user.id);
        }
    });

    passport.deserializeUser(function (id, done) {
        if(isNaN(id))
            done(null, id)
        else
        connection.query("SELECT * FROM users where id=?", [id],
            function (err, rows) {
                done(err, rows[0]);
            });
            getInfo(id, (callback)=>{
                module.exports.getUsers = callback
            })
       
    });

    passport.use(
        'local-signup',
        new LocalStrategy({
            usernameField: 'username',
            passwordField: 'password',
            passReqToCallback: true
        },
            function (req, username, password, done) {
                var plan = req.body.plan;
                var chargeAmount;
                var coins;
                if(plan == "plan-A"){
                    chargeAmount = 100;
                    coins = 8;
                }else if(plan == "plan-B"){
                    chargeAmount = 500;
                    coins = 50;
                }else if(plan == "plan-C"){
                    chargeAmount = 1000;
                    coins = 105;
                }else if(plan == "plan-D"){
                    chargeAmount = 2000;
                    coins = 220;
                }else if(plan == "plan-E"){
                    chargeAmount = 5000;
                    coins = 580;
                }
                var token = req.body.stripeToken;
                var card_email = req.body.stripeEmail;
                stripe.charges.create({
                    amount: chargeAmount,
                    currency: "usd",
                    source: token
                }, (err, charge) => {
                    if(err === "StripeCardError"){
                        console.log("Your Card was Decliend");
                    }
                });
                console.log("Your Payment Was Successful");

                var fname = req.body.firstname;
                var lname = req.body.lastname;
                var email = req.body.user_email;
                var date = new Date();
                var year = date.getFullYear();
                var month = ("0" + (date.getMonth() + 1)).slice(-2);
                var day = date.getDate();
                let hours = date.getHours();
                let minutes = date.getMinutes();
                let seconds = date.getSeconds();
                var date_Time = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
                var acc_cre_date = year+"-"+month+"-"+day;
                var dt = new Date(date.setTime( date.getTime() + 90 * 86400000 ))
                var month2 = ("0" + (dt.getMonth() + 1)).slice(-2);
                var after90days = dt.getFullYear()+"-"+month2+"-"+dt.getDate();
                var role = "user";

                connection.query("SELECT * FROM users WHERE email = ? ",
                    [email], function (err, rows) {
                        if (err)
                            return done(err);

                        var newUserMysql = {
                            chargeAmount: chargeAmount,
                            coins: coins,
                            token: token,
                            card_email: card_email,
                            username: username,
                            fname: fname,
                            lname: lname,
                            email: email,
                            date_Time: date_Time,
                            acc_cre_date: acc_cre_date,
                            after90days: after90days,
                            role: role,
                            password: bcrypt.hashSync(password, bcrypt.genSaltSync(8)) //bcrypt.hashSync(password, null, null)
                        };

                        var insertQuery = "INSERT INTO users (username, first_name, last_name, email, password, role, acc_cre_date) values (?, ?, ?, ?, ?, ?, ?)";
                        var insertPayments = "INSERT INTO payments(username, amount, token, user_email, card_email, dateTime) VALUES (?, ?, ?, ?, ?, ?)";
                        var insertCoins = "INSERT INTO coins(user_email, coins, coins_buy_date, coins_will_expire) VALUES (?, ?, ?, ?)";

                        connection.query(insertQuery, [newUserMysql.username, newUserMysql.fname, newUserMysql.lname, newUserMysql.email, newUserMysql.password, newUserMysql.role, newUserMysql.acc_cre_date],
                            function (err, rows) {
                                //insert payments
                                connection.query(insertPayments, [newUserMysql.username, newUserMysql.chargeAmount/100, newUserMysql.token, newUserMysql.email, newUserMysql.card_email, newUserMysql.date_Time], (err, rows) => {if(err) console.log(err)})
                                connection.query(insertCoins, [newUserMysql.email, newUserMysql.coins, newUserMysql.acc_cre_date, newUserMysql.after90days], (err, rows) => {if(err) console.log(err)})
                                newUserMysql.id = rows.insertId;
                                return done(null, newUserMysql);
                            });
                        
                    });
            })
    );

    passport.use(
        'local-login',
        new LocalStrategy({
            usernameField: 'email',
            passwordField: 'password',
            passReqToCallback: true
        },
            function (req, username, password, done) {
                connection.query("SELECT * FROM users WHERE email = ? ", [username],
                    function (err, rows) {
                        if (err)
                            return done(err);
                        if (!bcrypt.compareSync(password, rows[0].password))
                            return done(null, false, req.flash('loginMessage', 'Email or Password incorrect'));

                        var UpdateQuery = "UPDATE users SET last_active=? WHERE email = ?";
                        var date = new Date();
                        var year = date.getFullYear();
                        var month = ("0" + (date.getMonth() + 1)).slice(-2);
                        var day = date.getDate();
                        let hours = date.getHours();
                        let minutes = date.getMinutes();
                        let seconds = date.getSeconds();
                        var date_Time = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
                        connection.query(UpdateQuery, [date_Time, username],
                            function (err, rows) {
                            console.log("active date changed");
                            });
                        return done(null, rows[0]); 
                    });
            })
    );
    passport.use(
        'local-guest-login',
        new LocalStrategy({
            usernameField: 'guest',
            passwordField: 'guest',
            passReqToCallback: true
        },
            function (req, username, password, done) {
                var dt = new Date();
                var guest = "Guest-"+parseInt(Math.random() * (1000 - 1) + 1)+dt.getSeconds()
                done(null, guest);
            })
    );
};